# GP360

This is a markdown-based admin panel handbook site for Zoho Cliq, themed in green for a professional look.

## Hosting on GitHub Pages

1. Fork or clone this repo.
2. Enable GitHub Pages in repo settings (root or `/docs` folder).
3. Visit the published site URL.

## Customize

Edit any `.md` file to update content.
Use `_config.yml` to adjust site settings.
