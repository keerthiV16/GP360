# Managing Your Organization

- Adjust Policies
- Add Roles & Permissions
- Configure Module Access