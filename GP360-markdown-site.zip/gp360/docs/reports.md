# Reports

- Usage Reports
- Availability, Attendance & User Reports