# Initial Setup

- Invite Users
- Create Departments
- Collaborate in Channels