# Setting Up Your Organization

- Connect Workplace Apps
- Create Networks
- Install Extensions & Workflows